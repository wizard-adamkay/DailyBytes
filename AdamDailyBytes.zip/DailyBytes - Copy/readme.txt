Setup:
1. Run npm install on the frontend
2. run sql setup script in backend/DAL
