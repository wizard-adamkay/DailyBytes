﻿using DailyBytesDataAccessLayer.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace DailyBytesDataAccessLayer
{
    public class DailyBytesRepository
    {
        private DailyBytesDbContext context;
        public DailyBytesRepository(DailyBytesDbContext context)
        {
            this.context = context;
        }

        public int AddUser(User newUser)
        {
            SqlParameter prmFirstName = new SqlParameter("@FirstName", newUser.FirstName);
            SqlParameter prmLastName = new SqlParameter("@LastName", newUser.LastName);
            SqlParameter prmEmail = new SqlParameter("@Email", newUser.Email);
            SqlParameter prmUsername = new SqlParameter("@Username", newUser.Username);
            SqlParameter prmPassword = new SqlParameter("@Password", newUser.Password);
            SqlParameter prmGender = new SqlParameter("@Gender", newUser.Gender);
            SqlParameter prmContactNumber = new SqlParameter("@ContactNumber", newUser.ContactNumber);
            SqlParameter prmDateOfBirth = new SqlParameter("@DateOfBirth", newUser.DateOfBirth);
            SqlParameter prmAddress = new SqlParameter("@Address", newUser.Address);
            SqlParameter prmProfilePicture = new SqlParameter("@ProfilePicture", newUser.ProfilePicture);
            SqlParameter prmReturnResult = new SqlParameter("@ReturnResult", System.Data.SqlDbType.Int);
            prmReturnResult.Direction = System.Data.ParameterDirection.Output;
            int returnResult = 0;
            try
            {
                context.Database.ExecuteSqlRaw("EXEC @ReturnResult = usp_AddUser @FirstName, @LastName, @Email, @Username, @Password, @Gender, @ContactNumber, @DateOfBirth, @Address, @ProfilePicture",
                    prmReturnResult, prmFirstName, prmLastName, prmEmail, prmUsername, prmPassword, prmGender, prmContactNumber, prmDateOfBirth, prmAddress, prmProfilePicture);
                returnResult = Convert.ToInt32(prmReturnResult.Value);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                returnResult = -99;
            }
            return returnResult;
        }

        public User Login(string username, string password)
        {
            User user = new User();
            try
            {
                user = context.Users.Where(u => u.Username == username && u.Password == password).FirstOrDefault();
                return user;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public int UpdateBasicUser(User newUser)
        {
            User oldUser = new User();
            try
            {
                oldUser = context.Users.FirstOrDefault(u => u.UserId == newUser.UserId);
                if (oldUser == null)
                {
                    return -1;
                }
                
                if (newUser.FirstName != null)
                    oldUser.FirstName = newUser.FirstName;

                if (newUser.LastName != null)
                    oldUser.LastName = newUser.LastName;

                if (newUser.Email != null)
                    oldUser.Email = newUser.Email;

                if (newUser.Username != null)
                    oldUser.Username = newUser.Username;

                if (!string.IsNullOrWhiteSpace(newUser.Password))
                    oldUser.Password = newUser.Password;

                if (newUser.Gender != null)
                    oldUser.Gender = newUser.Gender;

                if (newUser.ContactNumber != 0)
                    oldUser.ContactNumber = newUser.ContactNumber;

                if (newUser.DateOfBirth != default(DateOnly))
                    oldUser.DateOfBirth = newUser.DateOfBirth;

                if (newUser.Address != null)
                    oldUser.Address = newUser.Address;

                if (newUser.ProfilePicture != null)
                    oldUser.ProfilePicture = newUser.ProfilePicture;

                context.SaveChanges();
            } 
            catch (Exception e)
            {
                return -99;
            }
            return 1;
        }

        public int UpdateExtendedUser(User updatedUser, Profile updatedProfile)
        {
            try
            {
                var oldUser = context.Users.FirstOrDefault(u => u.UserId == updatedUser.UserId);
                if (oldUser == null)
                    return -1;

                
                if (updatedUser.FirstName != null)
                    oldUser.FirstName = updatedUser.FirstName;

                if (updatedUser.LastName != null)
                    oldUser.LastName = updatedUser.LastName;

                if (updatedUser.Email != null)
                    oldUser.Email = updatedUser.Email;

                if (updatedUser.Username != null)
                    oldUser.Username = updatedUser.Username;

                if (!string.IsNullOrWhiteSpace(updatedUser.Password))
                    oldUser.Password = updatedUser.Password;

                if (updatedUser.Gender != null)
                    oldUser.Gender = updatedUser.Gender;

                if (updatedUser.ContactNumber != 0)
                    oldUser.ContactNumber = updatedUser.ContactNumber;

                if (updatedUser.DateOfBirth != default(DateOnly))
                    oldUser.DateOfBirth = updatedUser.DateOfBirth;

                if (updatedUser.Address != null)
                    oldUser.Address = updatedUser.Address;

                if (updatedUser.ProfilePicture != null)
                    oldUser.ProfilePicture = updatedUser.ProfilePicture;

                
                var oldProfile = context.Profiles.FirstOrDefault(p => p.UserId == updatedUser.UserId);
                if (oldProfile == null)
                {
                    oldProfile = new Profile
                    {
                        UserId = updatedUser.UserId
                    };
                    context.Profiles.Add(oldProfile);
                }

                
                if (updatedProfile.Bio != null)
                    oldProfile.Bio = updatedProfile.Bio;

                if (updatedProfile.Interests != null)
                    oldProfile.Interests = updatedProfile.Interests;

                if (updatedProfile.Experience != null)
                    oldProfile.Experience = updatedProfile.Experience;

                if (updatedProfile.Views != null)
                    oldProfile.Views = updatedProfile.Views;

                if (updatedProfile.Twitter != null)
                    oldProfile.Twitter = updatedProfile.Twitter;

                if (updatedProfile.Facebook != null)
                    oldProfile.Facebook = updatedProfile.Facebook;

                if (updatedProfile.Instagram != null)
                    oldProfile.Instagram = updatedProfile.Instagram;

                if (updatedProfile.LinkedIn != null)
                    oldProfile.LinkedIn = updatedProfile.LinkedIn;

                context.SaveChanges();
                return 1;
            }
            catch (Exception ex)
            {
                return -99;
            }
        }

        public User GetUserByUsername(string username)
        {
            return context.Users.FirstOrDefault(u => u.Username == username);
        }

        public Profile GetProfileByUserId(int userId)
        {
            return context.Profiles.FirstOrDefault(p => p.UserId == userId);
        }

        public List<Article> GetArticlesByUserId(int userId)
        {
            return context.Articles.Where(p => p.AuthorId == userId).ToList();
        }

        public int CreateArticle(Article article)
        {
            try
            {
                context.Articles.Add(article);
                context.SaveChanges();
                return article.ArticleId;
            }
            catch
            {
                return -99;
            }
        }

        public List<User> GetAllEditors()
        {
            return context.Users.Where(p => p.Role == "Editor").ToList();
        }

        public int SaveArticle(Article updatedArticle)
        {
            Article oldArticle = new Article();
            try
            {
                oldArticle = context.Articles.FirstOrDefault(a => a.ArticleId == updatedArticle.ArticleId);
                if (oldArticle == null)
                {
                    return -1;
                }
                oldArticle.Headline = updatedArticle.Headline;
                oldArticle.Subheading = updatedArticle.Subheading;
                oldArticle.Content = updatedArticle.Content;
                oldArticle.Image = updatedArticle.Image;
                oldArticle.Category = updatedArticle.Category;
                oldArticle.EditorId = updatedArticle.EditorId;
                context.SaveChanges();
            }
            catch(Exception ex)
            {
                return -99;
            }
            return 1;
        }

        public int SubmitArticle(Article updatedArticle)
        {
            Article oldArticle = new Article();
            try
            {
                oldArticle = context.Articles.FirstOrDefault(a => a.ArticleId == updatedArticle.ArticleId);
                if (oldArticle == null)
                {
                    return -1;
                }
                
                oldArticle.Headline = updatedArticle.Headline;
                oldArticle.Subheading = updatedArticle.Subheading;
                oldArticle.Content = updatedArticle.Content;
                oldArticle.Image = updatedArticle.Image;
                oldArticle.Category = updatedArticle.Category;
                oldArticle.EditorId = updatedArticle.EditorId;
                oldArticle.Status = "Pending Approval";

                context.SaveChanges();
            }
            catch (Exception ex)
            {
                return -99;
            }
            return 1;
        }

        public User GetUserById(int userId)
        {
            return context.Users.FirstOrDefault(u => u.UserId == userId);
        }
        public Article GetArticleByArticleId(int articleId)
        {
            return context.Articles.FirstOrDefault(p => p.ArticleId == articleId);
        }
        public List<Article> GetSubmittedArticlesByEditorId(int editorId)
        {
            return context.Articles.Where(a => a.EditorId == editorId && a.Status == "Pending Approval").ToList();
        }
        public int UpdateArticleFromEditor(Article updatedArticle, bool removeImage)
        {
            try
            {
                var existing = context.Articles.FirstOrDefault(a => a.ArticleId == updatedArticle.ArticleId);
                if (existing == null)
                    return -1;

                existing.Headline = updatedArticle.Headline;
                existing.Subheading = updatedArticle.Subheading;
                existing.Content = updatedArticle.Content;
                existing.Category = updatedArticle.Category;
                existing.Status = updatedArticle.Status;


                if (removeImage)
                {
                    existing.Image = null;
                }
                else if (updatedArticle.Image != null)
                {
                    existing.Image = updatedArticle.Image;
                }

                context.SaveChanges();
                if(existing.Status == "Approved")
                {
                    CreateNotificationsForFollowers(existing.AuthorId, existing.ArticleId);
                }
                return 1;
            }
            catch
            {
                return -99;
            }
        }

        public List<Article> GetArticlesByStatus(string status)
        {
            return context.Articles.Where(a => a.Status == status).ToList();
        }

        public int AddBookmark(int userId, int articleId)
        {
            try
            {
                if (!context.Bookmarks.Any(b => b.UserId == userId && b.ArticleId == articleId))
                {
                    context.Bookmarks.Add(new Bookmark { UserId = userId, ArticleId = articleId });
                    context.SaveChanges();
                }
                return 1;
            }
            catch(Exception ex)
            {
                return -99;
            }
        }

        public int RemoveBookmark(int userId, int articleId)
        {
            try
            {
                var entry = context.Bookmarks.FirstOrDefault(b => b.UserId == userId && b.ArticleId == articleId);
                if (entry != null)
                {
                    context.Bookmarks.Remove(entry);
                    context.SaveChanges();
                }
                return 1;
            }
            catch (Exception ex)
            {
                return -99;
            }
        }

        public List<Article> GetBookmarkedArticles(int userId)
        {
            return context.Bookmarks
                .Where(b => b.UserId == userId)
                .Select(b => b.Article)
                .ToList();
        }

        public int SetUserCategories(int userId, List<string> categories)
        {
            try
            {
                var existing = context.UserCategoryPreferences.Where(p => p.UserId == userId);
                context.UserCategoryPreferences.RemoveRange(existing);

                foreach (var category in categories)
                {
                    context.UserCategoryPreferences.Add(new UserCategoryPreference
                    {
                        UserId = userId,
                        Category = category
                    });
                }

                context.SaveChanges();
                return 1;
            }
            catch
            {
                return -99;
            }
        }

        public List<string> GetUserCategories(int userId)
        {
            return context.UserCategoryPreferences
                .Where(p => p.UserId == userId)
                .Select(p => p.Category)
                .ToList();
        }

        public int FollowUser(int followerId, int followeeId)
        {
            var follower = context.Users
                .Include(u => u.Followees)
                .FirstOrDefault(u => u.UserId == followerId);

            var followee = context.Users.Find(followeeId);

            if (follower == null || followee == null)
                return -1;

            if (!follower.Followees.Contains(followee))
            {
                follower.Followees.Add(followee);
                context.SaveChanges();
            }

            return 1;
        }

        public int UnfollowUser(int followerId, int followeeId)
        {
            var follower = context.Users
                .Include(u => u.Followees)
                .FirstOrDefault(u => u.UserId == followerId);

            var followee = context.Users.Find(followeeId);

            if (follower == null || followee == null)
                return -1;

            if (follower.Followees.Contains(followee))
            {
                follower.Followees.Remove(followee);
                context.SaveChanges();
            }

            return 1;
        }

        public bool IsFollowing(int followerId, int followeeId)
        {
            var follower = context.Users
                .Include(u => u.Followees)
                .FirstOrDefault(u => u.UserId == followerId);

            if (follower == null)
                return false;

            return follower.Followees.Any(u => u.UserId == followeeId);
        }

        public int AddComment(int articleId, int userId, string content)
        {
            try
            {
                var comment = new Comment
                {
                    ArticleId = articleId,
                    UserId = userId,
                    Content = content,
                    CreatedAt = DateTime.Now
                };

                context.Comments.Add(comment);
                context.SaveChanges();
                return 1;
            }
            catch
            {
                return -99;
            }
        }

        public List<object> GetCommentsForArticle(int articleId)
        {
            return context.Comments
                .Where(c => c.ArticleId == articleId)
                .OrderByDescending(c => c.CreatedAt)
                .Select(c => new
                {
                    c.CommentId,
                    c.Content,
                    c.CreatedAt,
                    Username = c.User.Username
                })
                .ToList<object>();
        }

        public int SetArticleRating(int articleId, int userId, int stars)
        {
            try
            {
                var existing = context.Ratings.FirstOrDefault(r => r.ArticleId == articleId && r.UserId == userId);
                if (existing != null)
                {
                    existing.Stars = stars;
                }
                else
                {
                    context.Ratings.Add(new Rating { ArticleId = articleId, UserId = userId, Stars = stars });
                }
                context.SaveChanges();
                return 1;
            }
            catch
            {
                return -99;
            }
        }

        public double GetAverageRating(int articleId)
        {
            var ratings = context.Ratings.Where(r => r.ArticleId == articleId).ToList();
            return ratings.Average(r => r.Stars) ?? 0;
        }

        public int? GetUserRating(int articleId, int userId)
        {
            return context.Ratings
                         .Where(r => r.ArticleId == articleId && r.UserId == userId)
                         .Select(r => (int?)r.Stars)
                         .FirstOrDefault();
        }

        public int ReportArticle(int userId, int articleId)
        {
            try
            {
                var user = context.Users
                    .Include(u => u.Articles)
                    .FirstOrDefault(u => u.UserId == userId);

                var article = context.Articles.Find(articleId);

                if (user == null || article == null)
                    return -1;

                if (!user.Articles.Contains(article))
                {
                    user.Articles.Add(article);
                    context.SaveChanges();
                }

                return 1;
            }
            catch
            {
                return -99;
            }
        }

        public List<object> SearchArticles(string? keyword, string? category)
        {
            var query = context.Articles
                .Where(a => a.Status == "Approved")
                .AsQueryable();

            if (!string.IsNullOrEmpty(keyword))
            {
                string lower = keyword.ToLower();
                query = query.Where(a =>
                    a.Headline.ToLower().Contains(lower) ||
                    a.Subheading.ToLower().Contains(lower) ||
                    a.Content.ToLower().Contains(lower));
            }

            if (!string.IsNullOrEmpty(category))
            {
                query = query.Where(a => a.Category == category);
            }

            return query
                .OrderByDescending(a => a.ArticleId)
                .Select(a => new
                {
                    a.ArticleId,
                    a.Headline,
                    a.Subheading,
                    a.Category,
                    a.AuthorId,
                    a.Status
                })
                .ToList<object>();
        }

        public void CreateNotificationsForFollowers(int authorId, int articleId)
        {
            var followers = context.Users
                .Where(u => u.Followees.Any(f => f.UserId == authorId))
                .ToList();

            foreach (var user in followers)
            {
                context.Notifications.Add(new Notification
                {
                    UserId = user.UserId,
                    ArticleId = articleId,
                    IsRead = false
                });
            }

            context.SaveChanges();
        }

        public List<object> GetUserNotifications(int userId)
        {
            return context.Notifications
                .Where(n => n.UserId == userId && (n.IsRead ?? false) == false)
                .OrderByDescending(n => n.CreatedAt)
                .Select(n => new
                {
                    n.NotificationId,
                    n.ArticleId,
                    ArticleHeadline = n.Article.Headline,
                    Author = n.Article.Author.Username,
                    n.CreatedAt
                })
                .ToList<object>();
        }

        public void MarkNotificationAsRead(int notificationId)
        {
            var note = context.Notifications.FirstOrDefault(n => n.NotificationId == notificationId);
            if (note != null)
            {
                note.IsRead = true;
                context.SaveChanges();
            }
        }
    }
}
