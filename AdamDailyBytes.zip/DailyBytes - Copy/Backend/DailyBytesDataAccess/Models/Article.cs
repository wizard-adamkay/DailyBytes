﻿using System;
using System.Collections.Generic;

namespace DailyBytesDataAccessLayer.Models;

public partial class Article
{
    public int ArticleId { get; set; }

    public string? Headline { get; set; }

    public string? Subheading { get; set; }

    public string? Content { get; set; }

    public byte[]? Image { get; set; }

    public string? Category { get; set; }

    public string Status { get; set; } = null!;

    public int AuthorId { get; set; }

    public int? EditorId { get; set; }

    public virtual User Author { get; set; } = null!;

    public virtual ICollection<Bookmark> Bookmarks { get; set; } = new List<Bookmark>();

    public virtual ICollection<Comment> Comments { get; set; } = new List<Comment>();

    public virtual User? Editor { get; set; }

    public virtual ICollection<Notification> Notifications { get; set; } = new List<Notification>();

    public virtual ICollection<Rating> Ratings { get; set; } = new List<Rating>();

    public virtual ICollection<User> Users { get; set; } = new List<User>();
}
