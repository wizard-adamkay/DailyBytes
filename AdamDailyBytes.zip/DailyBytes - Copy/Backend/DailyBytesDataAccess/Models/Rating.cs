﻿using System;
using System.Collections.Generic;

namespace DailyBytesDataAccessLayer.Models;

public partial class Rating
{
    public int ArticleId { get; set; }

    public int UserId { get; set; }

    public int? Stars { get; set; }

    public virtual Article Article { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
