﻿using System;
using System.Collections.Generic;

namespace DailyBytesDataAccessLayer.Models;

public partial class Bookmark
{
    public int UserId { get; set; }

    public int ArticleId { get; set; }

    public int? GarbageValue { get; set; }

    public virtual Article Article { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
