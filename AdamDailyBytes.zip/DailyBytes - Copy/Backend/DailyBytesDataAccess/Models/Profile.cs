﻿using System;
using System.Collections.Generic;

namespace DailyBytesDataAccessLayer.Models;

public partial class Profile
{
    public int ProfileId { get; set; }

    public int UserId { get; set; }

    public string? Bio { get; set; }

    public string? Interests { get; set; }

    public string? Experience { get; set; }

    public string? Views { get; set; }

    public string? Twitter { get; set; }

    public string? Facebook { get; set; }

    public string? Instagram { get; set; }

    public string? LinkedIn { get; set; }

    public virtual User User { get; set; } = null!;
}
