﻿using System;
using System.Collections.Generic;

namespace DailyBytesDataAccessLayer.Models;

public partial class UserCategoryPreference
{
    public int UserId { get; set; }

    public string Category { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
