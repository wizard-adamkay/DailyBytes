﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace DailyBytesDataAccessLayer.Models;

public partial class DailyBytesDbContext : DbContext
{
    public DailyBytesDbContext()
    {
    }

    public DailyBytesDbContext(DbContextOptions<DailyBytesDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Article> Articles { get; set; }

    public virtual DbSet<Bookmark> Bookmarks { get; set; }

    public virtual DbSet<Comment> Comments { get; set; }

    public virtual DbSet<Notification> Notifications { get; set; }

    public virtual DbSet<Profile> Profiles { get; set; }

    public virtual DbSet<Rating> Ratings { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<UserCategoryPreference> UserCategoryPreferences { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source =(localdb)\\MSSQLLocalDB;Initial Catalog=DailyBytesDB;Integrated Security=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Article>(entity =>
        {
            entity.HasKey(e => e.ArticleId).HasName("PK__Articles__9C6270E8BE7AD58B");

            entity.Property(e => e.Category).HasMaxLength(100);
            entity.Property(e => e.Headline).HasMaxLength(255);
            entity.Property(e => e.Status).HasMaxLength(20);
            entity.Property(e => e.Subheading).HasMaxLength(255);

            entity.HasOne(d => d.Author).WithMany(p => p.ArticleAuthors)
                .HasForeignKey(d => d.AuthorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Articles__Author__7C4F7684");

            entity.HasOne(d => d.Editor).WithMany(p => p.ArticleEditors)
                .HasForeignKey(d => d.EditorId)
                .HasConstraintName("FK__Articles__Editor__7D439ABD");
        });

        modelBuilder.Entity<Bookmark>(entity =>
        {
            entity.HasKey(e => new { e.UserId, e.ArticleId }).HasName("PK__Bookmark__8E4EEB4204F0B280");

            entity.HasOne(d => d.Article).WithMany(p => p.Bookmarks)
                .HasForeignKey(d => d.ArticleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Bookmarks__Artic__10566F31");

            entity.HasOne(d => d.User).WithMany(p => p.Bookmarks)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Bookmarks__UserI__0F624AF8");
        });

        modelBuilder.Entity<Comment>(entity =>
        {
            entity.HasKey(e => e.CommentId).HasName("PK__Comments__C3B4DFCAA16BD29F");

            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.Article).WithMany(p => p.Comments)
                .HasForeignKey(d => d.ArticleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Comments__Articl__1AD3FDA4");

            entity.HasOne(d => d.User).WithMany(p => p.Comments)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Comments__UserId__1BC821DD");
        });

        modelBuilder.Entity<Notification>(entity =>
        {
            entity.HasKey(e => e.NotificationId).HasName("PK__Notifica__20CF2E122EB8EC0F");

            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.IsRead).HasDefaultValue(false);

            entity.HasOne(d => d.Article).WithMany(p => p.Notifications)
                .HasForeignKey(d => d.ArticleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Notificat__Artic__2A164134");

            entity.HasOne(d => d.User).WithMany(p => p.Notifications)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Notificat__UserI__29221CFB");
        });

        modelBuilder.Entity<Profile>(entity =>
        {
            entity.HasKey(e => e.ProfileId).HasName("PK__Profiles__290C88E4865B2523");

            entity.HasIndex(e => e.UserId, "UQ__Profiles__1788CC4D647C163E").IsUnique();

            entity.Property(e => e.Experience).HasMaxLength(255);
            entity.Property(e => e.Facebook).HasMaxLength(255);
            entity.Property(e => e.Instagram).HasMaxLength(255);
            entity.Property(e => e.Interests).HasMaxLength(255);
            entity.Property(e => e.LinkedIn).HasMaxLength(255);
            entity.Property(e => e.Twitter).HasMaxLength(255);

            entity.HasOne(d => d.User).WithOne(p => p.Profile)
                .HasForeignKey<Profile>(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Profiles__UserId__787EE5A0");
        });

        modelBuilder.Entity<Rating>(entity =>
        {
            entity.HasKey(e => new { e.ArticleId, e.UserId }).HasName("PK__Ratings__4D1AFC2CC9AEDC5A");

            entity.HasOne(d => d.Article).WithMany(p => p.Ratings)
                .HasForeignKey(d => d.ArticleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Ratings__Article__1F98B2C1");

            entity.HasOne(d => d.User).WithMany(p => p.Ratings)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Ratings__UserId__208CD6FA");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__Users__1788CCAC14392595");

            entity.HasIndex(e => e.Username, "UQ__Users__536C85E4B74606E7").IsUnique();

            entity.Property(e => e.UserId).HasColumnName("UserID");
            entity.Property(e => e.Address).HasMaxLength(255);
            entity.Property(e => e.Email).HasMaxLength(320);
            entity.Property(e => e.FirstName).HasMaxLength(50);
            entity.Property(e => e.Gender).HasMaxLength(30);
            entity.Property(e => e.LastName).HasMaxLength(50);
            entity.Property(e => e.Password).HasMaxLength(200);
            entity.Property(e => e.Role)
                .HasMaxLength(20)
                .HasDefaultValue("User");
            entity.Property(e => e.Username).HasMaxLength(30);

            entity.HasMany(d => d.Articles).WithMany(p => p.Users)
                .UsingEntity<Dictionary<string, object>>(
                    "ArticleReport",
                    r => r.HasOne<Article>().WithMany()
                        .HasForeignKey("ArticleId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ArticleRe__Artic__245D67DE"),
                    l => l.HasOne<User>().WithMany()
                        .HasForeignKey("UserId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ArticleRe__UserI__236943A5"),
                    j =>
                    {
                        j.HasKey("UserId", "ArticleId").HasName("PK__ArticleR__8E4EEB42737C88AB");
                        j.ToTable("ArticleReports");
                    });

            entity.HasMany(d => d.Followees).WithMany(p => p.Followers)
                .UsingEntity<Dictionary<string, object>>(
                    "UserFollow",
                    r => r.HasOne<User>().WithMany()
                        .HasForeignKey("FolloweeId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__UserFollo__Follo__17036CC0"),
                    l => l.HasOne<User>().WithMany()
                        .HasForeignKey("FollowerId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__UserFollo__Follo__160F4887"),
                    j =>
                    {
                        j.HasKey("FollowerId", "FolloweeId").HasName("PK__UserFoll__67A1FC7CA61E22E4");
                        j.ToTable("UserFollows");
                    });

            entity.HasMany(d => d.Followers).WithMany(p => p.Followees)
                .UsingEntity<Dictionary<string, object>>(
                    "UserFollow",
                    r => r.HasOne<User>().WithMany()
                        .HasForeignKey("FollowerId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__UserFollo__Follo__160F4887"),
                    l => l.HasOne<User>().WithMany()
                        .HasForeignKey("FolloweeId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__UserFollo__Follo__17036CC0"),
                    j =>
                    {
                        j.HasKey("FollowerId", "FolloweeId").HasName("PK__UserFoll__67A1FC7CA61E22E4");
                        j.ToTable("UserFollows");
                    });
        });

        modelBuilder.Entity<UserCategoryPreference>(entity =>
        {
            entity.HasKey(e => new { e.UserId, e.Category }).HasName("PK__UserCate__3333BF8F1EC97634");

            entity.Property(e => e.Category).HasMaxLength(50);

            entity.HasOne(d => d.User).WithMany(p => p.UserCategoryPreferences)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__UserCateg__UserI__1332DBDC");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
