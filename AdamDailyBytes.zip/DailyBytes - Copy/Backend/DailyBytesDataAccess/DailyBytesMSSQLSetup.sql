﻿CREATE DATABASE DailyBytesDB
USE DailyBytesDB
DROP TABLE Notifications
DROP TABLE ArticleReports
DROP TABLE Ratings
DROP TABLE Comments
DROP TABLE UserFollows
DROP TABLE UserCategoryPreferences
DROP TABLE Bookmarks
DROP TABLE Profiles
DROP TABLE Articles
DROP TABLE Users

CREATE TABLE Users
(
	UserID INT IDENTITY(1,1) PRIMARY KEY,
	FirstName NVARCHAR(50) NOT NULL,
	LastName NVARCHAR(50) NOT NULL,
	Email NVARCHAR(320) NOT NULL,
	Username NVARCHAR(30) UNIQUE NOT NULL,
	[Password] NVARCHAR(200) NOT NULL,
	Gender NVARCHAR(30) NOT NULL CHECK (Gender IN ('Male', 'Female', 'Other')),
	ContactNumber INT NOT NULL CHECK (LEN(ContactNumber) = 10 AND ContactNumber NOT LIKE '%[^0-9]%'),
	DateOfBirth DATE  NOT NULL CHECK (DateOfBirth < GETDATE()),
	[Address] NVARCHAR(255) NOT NULL,
	ProfilePicture VARBINARY(MAX) NOT NULL,
	[Role] NVARCHAR(20) NOT NULL DEFAULT 'User' CHECK([Role] IN ('User', 'Journalist', 'Editor', 'Chief Editor'))
)

CREATE TABLE Profiles (
    ProfileId INT PRIMARY KEY IDENTITY,
    UserId INT NOT NULL UNIQUE FOREIGN KEY REFERENCES Users(UserId),
    Bio NVARCHAR(MAX),
    Interests NVARCHAR(255),
    Experience NVARCHAR(255),
    [Views] NVARCHAR(MAX),
    Twitter NVARCHAR(255),
    Facebook NVARCHAR(255),
    Instagram NVARCHAR(255),
    LinkedIn NVARCHAR(255)
);

CREATE TABLE Articles (
    ArticleId INT PRIMARY KEY IDENTITY,
    Headline NVARCHAR(255),
    Subheading NVARCHAR(255),
    Content NVARCHAR(MAX),
    Image VARBINARY(MAX),
    Category NVARCHAR(100),
    Status NVARCHAR(20) NOT NULL CHECK (Status IN ('Authoring', 'Pending Approval', 'Approved')),

    AuthorId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
    EditorId INT NULL FOREIGN KEY REFERENCES Users(UserId)
);

CREATE TABLE Bookmarks (
    UserId INT NOT NULL,
    ArticleId INT NOT NULL,
	GarbageValue INT NULL,
    PRIMARY KEY (UserId, ArticleId),
    FOREIGN KEY (UserId) REFERENCES Users(UserID),
    FOREIGN KEY (ArticleId) REFERENCES Articles(ArticleId)
);

CREATE TABLE UserCategoryPreferences (
    UserId INT NOT NULL,
    Category NVARCHAR(50) NOT NULL,
    PRIMARY KEY (UserId, Category),
    FOREIGN KEY (UserId) REFERENCES Users(UserID)
);

CREATE TABLE UserFollows (
    FollowerId INT NOT NULL,
    FolloweeId INT NOT NULL,
    PRIMARY KEY (FollowerId, FolloweeId),
    FOREIGN KEY (FollowerId) REFERENCES Users(UserID),
    FOREIGN KEY (FolloweeId) REFERENCES Users(UserID)
);

CREATE TABLE Comments (
    CommentId INT IDENTITY(1,1) PRIMARY KEY,
    ArticleId INT NOT NULL,
    UserId INT NOT NULL,
    Content NVARCHAR(MAX) NOT NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (ArticleId) REFERENCES Articles(ArticleId),
    FOREIGN KEY (UserId) REFERENCES Users(UserId)
);

CREATE TABLE Ratings (
    ArticleId INT NOT NULL,
    UserId INT NOT NULL,
    Stars INT CHECK (Stars BETWEEN 1 AND 5),
    PRIMARY KEY (ArticleId, UserId),
    FOREIGN KEY (ArticleId) REFERENCES Articles(ArticleId),
    FOREIGN KEY (UserId) REFERENCES Users(UserId)
);

CREATE TABLE ArticleReports (
    UserId INT NOT NULL,
    ArticleId INT NOT NULL,
    PRIMARY KEY (UserId, ArticleId),
    FOREIGN KEY (UserId) REFERENCES Users(UserId),
    FOREIGN KEY (ArticleId) REFERENCES Articles(ArticleId)
);

CREATE TABLE Notifications (
    NotificationId INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NOT NULL,
    ArticleId INT NOT NULL,
    IsRead BIT DEFAULT 0,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (UserId) REFERENCES Users(UserId),
    FOREIGN KEY (ArticleId) REFERENCES Articles(ArticleId)
);

GO
CREATE PROCEDURE usp_AddUser
	@FirstName NVARCHAR(50),
	@LastName NVARCHAR(50),
	@Email NVARCHAR(320),
	@Username NVARCHAR(30),
	@Password NVARCHAR(200),
	@Gender NVARCHAR(30),
	@ContactNumber VARCHAR(10),
	@DateOfBirth DATE,
	@Address NVARCHAR(255),
	@ProfilePicture VARBINARY(MAX)
AS
BEGIN
	DECLARE @ReturnResult INT
	IF @FirstName LIKE '%[^A-Za-z]%' OR @LastName LIKE '%[^A-Za-z]%'
	BEGIN
		RAISERROR('Names must only contain alphabetical characters.', 16, 1);
		SET @ReturnResult = -1;
		RETURN @ReturnResult;
	END

	IF @Email NOT LIKE '%_@__%.__%'
	BEGIN
		RAISERROR('Invalid email format.', 16, 1);
		SET @ReturnResult = -2;
		RETURN @ReturnResult;
	END
	IF EXISTS(SELECT @Username FROM Users WHERE Username=@Username)
		BEGIN
			SET @ReturnResult = -3;
			RETURN @ReturnResult;
		END
	INSERT INTO Users (
		FirstName, LastName, Email, Username, [Password], Gender,
		ContactNumber, DateOfBirth, [Address], ProfilePicture)
	VALUES (
		@FirstName, @LastName, @Email, @Username, @Password, @Gender,
		@ContactNumber, @DateOfBirth, @Address, @ProfilePicture);
	SET @ReturnResult = 1;
	RETURN @ReturnResult;
END