﻿namespace DailyBytesServiceLayer.Models
{
    public class FollowDTO
    {
        public int FollowerId { get; set; }
        public int FolloweeId { get; set; }
    }
}
