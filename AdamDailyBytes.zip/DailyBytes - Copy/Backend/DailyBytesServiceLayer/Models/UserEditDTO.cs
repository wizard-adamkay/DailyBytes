﻿namespace DailyBytesServiceLayer.Models
{
    public class UserEditDTO
    {
        // for use sending data to prefill out the edit user page.
        public int UserId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string Username { get; set; }

        public string Gender { get; set; }

        public int ContactNumber { get; set; }

        public DateOnly DateOfBirth { get; set; }

        public string Address { get; set; }

        public string Role { get; set; }
        
        public string? Bio { get; set; }

        public string? Interests { get; set; }

        public string? Experience { get; set; }

        public string? Views { get; set; }

        public string? Twitter { get; set; }

        public string? Facebook { get; set; }

        public string? Instagram { get; set; }

        public string? LinkedIn { get; set; }

        public List<string> Categories { get; set; } = new();
    }
}
