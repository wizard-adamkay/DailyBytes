﻿namespace DailyBytesServiceLayer.Models
{
    public class ExtendedUserUpdateDTO : BasicUserUpdateDTO
    {
        public string Bio { get; set; }

        public string Interests { get; set; }

        public string Experience { get; set; }

        public string Views { get; set; }

        public string Twitter { get; set; }

        public string Facebook { get; set; }

        public string Instagram { get; set; }

        public string LinkedIn { get; set; }
    }
}
