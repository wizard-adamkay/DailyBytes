﻿using System.ComponentModel.DataAnnotations;

namespace DailyBytesServiceLayer.Models
{
    public class ArticleSubmitDTO
    {
        public int ArticleId { get; set; }
        [Required(ErrorMessage = "Headline is required.")]
        public string Headline { get; set; }
        [Required(ErrorMessage = "Subheading is required.")]
        public string Subheading { get; set; }
        [Required(ErrorMessage = "Content is required.")]
        public string Content { get; set; }

        public IFormFile? Image { get; set; }

        public string? Category { get; set; }
        public int AuthorId { get; set; }
        public int EditorId { get; set; }
    }
}
