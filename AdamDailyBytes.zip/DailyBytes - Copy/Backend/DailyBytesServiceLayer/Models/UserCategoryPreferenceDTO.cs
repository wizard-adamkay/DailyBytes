﻿namespace DailyBytesServiceLayer.Models
{
    public class UserCategoryPreferenceDTO
    {
        public int UserId { get; set; }
        public List<string> Categories { get; set; } = new();
    }
}
