﻿using DailyBytesDataAccessLayer.Models;

namespace DailyBytesServiceLayer.Models
{
    public class ArticleSaveDTO
    {
        public int ArticleId { get; set; }

        public string? Headline { get; set; }

        public string? Subheading { get; set; }

        public string? Content { get; set; }

        public IFormFile? Image { get; set; }

        public string? Category { get; set; }

        public int? EditorId { get; set; }
    }
}
