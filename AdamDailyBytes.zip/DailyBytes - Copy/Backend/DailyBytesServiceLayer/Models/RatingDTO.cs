﻿namespace DailyBytesServiceLayer.Models
{
    public class RatingDTO
    {
        public int ArticleId { get; set; }
        public int UserId { get; set; }
        public int Stars { get; set; }
    }
}
