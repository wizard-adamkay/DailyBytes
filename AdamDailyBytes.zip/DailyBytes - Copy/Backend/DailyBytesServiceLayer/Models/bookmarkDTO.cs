﻿namespace DailyBytesServiceLayer.Models
{
    public class BookmarkDTO
    {
        public int UserId { get; set; }
        public int ArticleId { get; set; }
    }
}
