﻿namespace DailyBytesServiceLayer.Models
{
    public class ArticleDTO
    {
        public int ArticleId { get; set; }

        public string? Headline { get; set; }

        public string? Subheading { get; set; }

        public string? Content { get; set; }

        public IFormFile? Image { get; set; }

        public string? Category { get; set; }

        public string? Status { get; set; }

        public int? AuthorId { get; set; }

        public int? EditorId { get; set; }
    }
}
