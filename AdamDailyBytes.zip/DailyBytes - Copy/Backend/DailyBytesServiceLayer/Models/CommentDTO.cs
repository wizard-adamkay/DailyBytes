﻿namespace DailyBytesServiceLayer.Models
{
    public class CommentDTO
    {
        public int ArticleId { get; set; }
        public int UserId { get; set; }
        public string Content { get; set; } = null!;
    }
}
