﻿namespace DailyBytesServiceLayer.Models
{
    public class ReportDTO
    {
        public int ArticleId { get; set; }
        public int UserId { get; set; }
    }
}
