﻿namespace DailyBytesServiceLayer.Models
{
    public class UserProfileViewDTO
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string Role { get; set; }
        public string ProfilePicture { get; set; }
        public string Bio { get; set; }
        public string Interests { get; set; }
        public string Experience { get; set; }
        public string Views { get; set; }
        public string Twitter { get; set; }
        public string Facebook { get; set; }
        public string Instagram { get; set; }
        public string LinkedIn { get; set; }
    }
}
