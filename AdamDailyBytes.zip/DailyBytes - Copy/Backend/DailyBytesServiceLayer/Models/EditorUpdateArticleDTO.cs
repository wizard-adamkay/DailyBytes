﻿namespace DailyBytesServiceLayer.Models
{
    public class EditorUpdateArticleDTO
    {
        public int ArticleId { get; set; }
        public string Headline { get; set; } = null!;
        public string Subheading { get; set; } = null!;
        public string Content { get; set; } = null!;
        public string? Category { get; set; }
        public string Status { get; set; } = null!;
        public IFormFile? Image { get; set; }
        public bool RemoveImage { get; set; }
    }
}
