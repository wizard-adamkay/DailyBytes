﻿using DailyBytesServiceLayer.Models;
using DailyBytesDataAccessLayer;
using Microsoft.AspNetCore.Mvc;
using DailyBytesDataAccessLayer.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DailyBytesServiceLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : Controller
    {

        DailyBytesRepository repository;

        public AuthController(DailyBytesRepository repository)
        {
            this.repository = repository;
        }

        // POST api/<AuthController>
        [HttpPost("register")]
        public JsonResult Register([FromForm] UserRegistrationDTO dtoUser)
        {
            int returnValue = 0;
            string message = "";


            byte[] pictureBytes = null;
            if (dtoUser.ProfilePicture != null)
            {
                if (dtoUser.ProfilePicture.ContentType != "image/png")
                {
                    return new JsonResult(new { success = false, message = "Only PNG images are supported." });
                }
                using (var ms = new MemoryStream())
                {
                    dtoUser.ProfilePicture.CopyTo(ms);
                    pictureBytes = ms.ToArray();
                }
            }
            var user = new User
            {
                UserId = -1,
                FirstName = dtoUser.FirstName,
                LastName = dtoUser.LastName,
                Email = dtoUser.Email,
                Username = dtoUser.Username,
                Password = dtoUser.Password,
                Gender = dtoUser.Gender,
                ContactNumber = dtoUser.ContactNumber,
                DateOfBirth = dtoUser.DateOfBirth,
                Address = dtoUser.Address,
                ProfilePicture = pictureBytes
            };
            try
            {
                returnValue = repository.AddUser(user);
                switch (returnValue)
                {
                    case 1:
                        message = "User Successfully registered!";
                        break;
                    case -1:
                        message = "Names must only have alphabetical letters with no spaces";
                        break;
                    case -2:
                        message = "Invalid email format";
                        break;
                    case -3:
                        message = "Username already taken";
                        break;
                    default:
                        message = "????";
                        break;
                }
            }
            catch (Exception e)
            {
                message = "an error occured, everybody panic";
            }
            return Json(new { success = returnValue == 1, message = message });
        }


        // POST api/<AuthController>
        [HttpPost("login")]
        public JsonResult Login([FromBody] UserLoginDTO dtoUser)
        {
            try
            {
                string message = "";
                var user = repository.Login(dtoUser.Username, dtoUser.Password);
                if (user != null)
                {
                    return new JsonResult(new
                    {
                        success = true,
                        message = "Login successful",
                        username = user.Username,
                        userID = user.UserId,
                        role = user.Role
                    });
                }

                return new JsonResult(new
                {
                    success = false,
                    message = "Invalid username or password"
                });
            }
            catch (Exception ex)
            {
                return new JsonResult(new
                {
                    success = false,
                    message = "An error occurred during login"
                });
            }
        }

        [HttpPut("update/basic")]
        public JsonResult UpdateBasicUser([FromForm] BasicUserUpdateDTO dto)
        {
            
            byte[] pictureBytes = null;
            if (dto.ProfilePicture != null && dto.ProfilePicture.Length > 0)
            {
                using (var ms = new MemoryStream())
                {
                    dto.ProfilePicture.CopyTo(ms);
                    pictureBytes = ms.ToArray();
                }
            }

            var user = new User
            {
                UserId = dto.UserId,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Email = dto.Email,
                Username = dto.Username,
                Password = dto.Password,
                Gender = dto.Gender,
                ContactNumber = dto.ContactNumber,
                DateOfBirth = dto.DateOfBirth,
                Address = dto.Address,
                ProfilePicture = pictureBytes
            };

            
            int result = repository.UpdateBasicUser(user);
            string message = "";
            switch (result)
            {
                case 1:
                    message = "User info updated.";
                    break;
                case -1:
                    message = "User not found.";
                    break;
                case -99:
                    message = "Something went wrong with user.";
                    break;
                default:
                    message = "Something went REALLY wrong with user.";
                    break;
            }

            var categories = Request.Form["Categories"].ToList();
            int catagoryResult = repository.SetUserCategories(dto.UserId, categories);

            switch (catagoryResult)
            {
                case 1:
                    message += " Catagories set successfully.";
                    break;
                case -99:
                    message += " Something went wrong with with categories.";
                    break;
                default:
                    message += " Something went REALLY wrong with catagories.";
                    break;
            }

            return new JsonResult(new { success = result == 1 && catagoryResult == 1, message = message });
        }

        [HttpPut("update/extended")]
        public JsonResult UpdateExtendedUser([FromForm] ExtendedUserUpdateDTO dto)
        {
            
            byte[] pictureBytes = null;
            if (dto.ProfilePicture != null && dto.ProfilePicture.Length > 0)
            {
                using (var ms = new MemoryStream())
                {
                    dto.ProfilePicture.CopyTo(ms);
                    pictureBytes = ms.ToArray();
                }
            }
            
            var user = new User
            {
                UserId = dto.UserId,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Email = dto.Email,
                Username = dto.Username,
                Password = dto.Password,
                Gender = dto.Gender,
                ContactNumber = dto.ContactNumber,
                DateOfBirth = dto.DateOfBirth,
                Address = dto.Address,
                ProfilePicture = pictureBytes
            };

            
            var profile = new Profile
            {
                UserId = dto.UserId,
                Bio = dto.Bio,
                Interests = dto.Interests,
                Experience = dto.Experience,
                Views = dto.Views,
                Twitter = dto.Twitter,
                Facebook = dto.Facebook,
                Instagram = dto.Instagram,
                LinkedIn = dto.LinkedIn
            };

            int result = repository.UpdateExtendedUser(user, profile);
            string message = "";
            switch (result)
            {
                case 1:
                    message = "User info updated.";
                    break;
                case -1:
                    message = "User not found.";
                    break;
                case -99:
                    message = "Something went wrong.";
                    break;
                default:
                    message = "Something went REALLY wrong.";
                    break;
            }

            var categories = Request.Form["Categories"].ToList();
            int catagoryResult = repository.SetUserCategories(dto.UserId, categories);

            switch (catagoryResult)
            {
                case 1:
                    message += " Catagories set successfully.";
                    break;
                case -99:
                    message += " Something went wrong with with categories.";
                    break;
                default:
                    message += " Something went REALLY wrong with catagories.";
                    break;
            }
            return new JsonResult(new { success = result == 1 && catagoryResult == 1, message = message });
        }

        [HttpGet("user/{username}")]
        public JsonResult GetUserProfile(string username)
        {
            try
            {
                var user = repository.GetUserByUsername(username);
                if (user == null)
                    return new JsonResult(new { success = false, message = "User not found" });

                var profile = repository.GetProfileByUserId(user.UserId);

                var dto = new UserProfileViewDTO {
                    UserId = user.UserId,
                    Username = user.Username,
                    Role = user.Role,
                    ProfilePicture = user.ProfilePicture != null ? Convert.ToBase64String(user.ProfilePicture) : null,
                    Interests = profile?.Interests,
                    Bio = profile?.Bio,
                    Experience = profile?.Experience,
                    Views = profile?.Views,
                    Twitter = profile?.Twitter,
                    Facebook = profile?.Facebook,
                    Instagram = profile?.Instagram,
                    LinkedIn = profile?.LinkedIn
                };

                return new JsonResult(new { success = true, data = dto });
            }
            catch (Exception ex)
            {
                return new JsonResult(new { success = false, message = "An error occurred while loading the profile." });
            }
        }

        [HttpGet("user/edit/{username}")]
        public JsonResult GetUserEditProfile(string username)
        {
            var user = repository.GetUserByUsername(username);
            if (user == null)
            {
                return new JsonResult(new { success = false, message = "User not found" });
            }

            var profile = repository.GetProfileByUserId(user.UserId);
            var catagories = repository.GetUserCategories(user.UserId);

            var dto = new UserEditDTO
            {
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                Username = user.Username,
                Gender = user.Gender,
                ContactNumber = user.ContactNumber,
                DateOfBirth = user.DateOfBirth,
                Address = user.Address,
                Role = user.Role,
                Bio = profile?.Bio,
                Interests = profile?.Interests,
                Experience = profile?.Experience,
                Views = profile?.Views,
                Twitter = profile?.Twitter,
                Facebook = profile?.Facebook,
                Instagram = profile?.Instagram,
                LinkedIn = profile?.LinkedIn,
                Categories = catagories
            };

            return new JsonResult(new { success = true, data = dto });
        }

        [HttpGet("editors")]
        public JsonResult getNamesOfAllEditors()
        {
            List<User> editors = repository.GetAllEditors();
            List<EditorIdentifiersDTO> editorsDTO = new List<EditorIdentifiersDTO>();
            foreach(User editor in editors)
            {
                editorsDTO.Add(new EditorIdentifiersDTO
                {
                    UserId = editor.UserId,
                    FirstName = editor.FirstName,
                    LastName = editor.LastName,
                    Username = editor.Username
                });
            }

            return new JsonResult(new { success = true, data = editorsDTO });
        }

        [HttpPost("set-category-preferences")]
        
        public IActionResult SetUserCategories([FromBody] UserCategoryPreferenceDTO dto)
        {
            var result = repository.SetUserCategories(dto.UserId, dto.Categories);
            return Ok(new { success = result == 1 });
        }

        [HttpGet("get-category-preferences/{userId}")]
        public IActionResult GetUserCategories(int userId)
        {
            var categories = repository.GetUserCategories(userId);
            return Ok(new { success = true, data = categories });
        }

        [HttpPost("follow")]
        public IActionResult FollowJournalist([FromBody] FollowDTO dto)
        {
            var result = repository.FollowUser(dto.FollowerId, dto.FolloweeId);
            return Ok(new { success = result == 1 });
        }

        [HttpDelete("unfollow")]
        public IActionResult UnfollowJournalist([FromBody] FollowDTO dto)
        {
            var result = repository.UnfollowUser(dto.FollowerId, dto.FolloweeId);
            return Ok(new { success = result == 1 });
        }

        [HttpGet("is-following/{followerId}/{followeeId}")]
        public IActionResult IsFollowing(int followerId, int followeeId)
        {
            bool isFollowing = repository.IsFollowing(followerId, followeeId);
            return Ok(new { success = true, isFollowing = isFollowing });
        }

        [HttpGet("notifications/{userId}")]
        public IActionResult GetNotifications(int userId)
        {
            var notes = repository.GetUserNotifications(userId);
            return Ok(new { success = true, data = notes });
        }

        [HttpPost("notifications/read/{notificationId}")]
        public IActionResult MarkAsRead(int notificationId)
        {
            repository.MarkNotificationAsRead(notificationId);
            return Ok(new { success = true });
        }
    }
}
