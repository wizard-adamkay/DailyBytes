﻿using DailyBytesDataAccessLayer;
using DailyBytesServiceLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DailyBytesServiceLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookmarkController : Controller
    {
        DailyBytesRepository repository;

        public BookmarkController(DailyBytesRepository repository)
        {
            this.repository = repository;
        }

        [HttpPost("bookmark")]
        public IActionResult AddBookmark([FromBody] BookmarkDTO dto)
        {
            var result = repository.AddBookmark(dto.UserId, dto.ArticleId);
            return Ok(new { success = result == 1 });
        }

        [HttpDelete("bookmark")]
        public IActionResult RemoveBookmark([FromBody] BookmarkDTO dto)
        {
            var result = repository.RemoveBookmark(dto.UserId, dto.ArticleId);
            return Ok(new { success = result == 1 });
        }

        [HttpGet("bookmarks/{userId}")]
        public IActionResult GetUserBookmarks(int userId)
        {
            var articles = repository.GetBookmarkedArticles(userId);
            return Ok(new { success = true, data = articles });
        }
    }
}
