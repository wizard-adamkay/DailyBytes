﻿using DailyBytesDataAccessLayer;
using DailyBytesDataAccessLayer.Models;
using DailyBytesServiceLayer.Models;
using Microsoft.AspNetCore.Mvc;

namespace DailyBytesServiceLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArticlesController : Controller
    {
        DailyBytesRepository repository;
        public ArticlesController(DailyBytesRepository repository)
        {
            this.repository = repository;
        }

        [HttpGet("{userId}")]
        public JsonResult GetArticles(int userId)
        {
            try
            {
                List<Article> articles = repository.GetArticlesByUserId(userId);
                return new JsonResult(new { success = true, data = articles });
            }
            catch (Exception ex)
            {
                return new JsonResult(new { success = false, message = "An error occurred while loading the profile." });
            }
        }

        [HttpPost("create")]
        public JsonResult CreateArticle([FromBody] ArticleDTO dto)
        {
            try
            {
                if (dto.AuthorId == null)
                {
                    return new JsonResult(new { success = false, message = "AuthorId is required. How on earth did this happen?" });
                }

                var article = new Article
                {
                    AuthorId = dto.AuthorId.Value,
                    Status = "Authoring"
                };

                int articleId = repository.CreateArticle(article);
                return new JsonResult(new { success = articleId != -99, articleId = articleId });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return new JsonResult(new { success = false, message = "Failed to create article." });
            }
        }

        [HttpPost("save")]
        public IActionResult SaveArticle([FromForm] ArticleSaveDTO dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                byte[] pictureBytes = null;
                if (dto.Image != null && dto.Image.Length > 0)
                {
                    using (var ms = new MemoryStream())
                    {
                        dto.Image.CopyTo(ms);
                        pictureBytes = ms.ToArray();
                    }
                }
                var article = new Article
                {
                    ArticleId = dto.ArticleId,
                    Headline = dto.Headline,
                    Subheading = dto.Subheading,
                    Content = dto.Content,
                    Image = pictureBytes,
                    Category = dto.Category,
                    EditorId = dto.EditorId
                };
                int result = repository.SaveArticle(article);
                string message = "";
                switch(result)
                {
                    case 1:
                        message = "Saved successfully.";
                        break;
                    case -1:
                        message = "Cannot find old article ID.";
                        break;
                    case -99:
                        message = "Exception occured in repository.";
                        break;
                }
                return Ok(new { success = result == 1, message = message });

            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "Exception occured." });
            }
        }


        [HttpPost("submit")]
        public IActionResult SaveAndSubmitArticle([FromForm] ArticleSubmitDTO dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                byte[] pictureBytes = null;
                if (dto.Image != null && dto.Image.Length > 0)
                {
                    using (var ms = new MemoryStream())
                    {
                        dto.Image.CopyTo(ms);
                        pictureBytes = ms.ToArray();
                    }
                }
                var article = new Article
                {
                    ArticleId = dto.ArticleId,
                    Headline = dto.Headline,
                    Subheading = dto.Subheading,
                    Content = dto.Content,
                    Image = pictureBytes,
                    Category = dto.Category,
                    AuthorId = dto.AuthorId,
                    EditorId = dto.EditorId
                };
                int result = repository.SubmitArticle(article);
                string message = "";
                switch (result)
                {
                    case 1:
                        message = "Submitted successfully.";
                        break;
                    case -1:
                        message = "Cannot find old article ID.";
                        break;
                    case -99:
                        message = "Exception occured in repository.";
                        break;
                }
                return Ok(new { success = result == 1, message = message });

            }
            catch (Exception ex)
            {
                return  StatusCode(500, new { success = false, message = "Exception occured." });
            }
        }

        [HttpGet("article/{articleId}")]
        public JsonResult GetArticleByArticleId(int articleId)
        {
            try
            {
                Article article = repository.GetArticleByArticleId(articleId);
                return new JsonResult(new { success = true, data = article });
            }
            catch (Exception ex)
            {
                return new JsonResult(new { success = false, message = "An error occurred while loading the profile." });
            }
        }

        [HttpGet("submitted-articles/{editorId}")]
        public JsonResult GetSubmittedArticlesByEditorId(int editorId)
        {
            try
            {
                List<Article> articles = repository.GetSubmittedArticlesByEditorId(editorId);
                return new JsonResult(new { success = true, data = articles });
            }
            catch (Exception ex)
            {
                return new JsonResult(new { success = false, message = "An error occurred while loading the profile." });
            }
        }

        [HttpPut("editor-update")]
        public IActionResult EditorUpdateArticle([FromForm] EditorUpdateArticleDTO dto)
        {
            try
            {
                byte[]? newImageBytes = null;

                if (dto.Image != null && dto.Image.Length > 0)
                {
                    using var ms = new MemoryStream();
                    dto.Image.CopyTo(ms);
                    newImageBytes = ms.ToArray();
                }

                var article = new Article
                {
                    ArticleId = dto.ArticleId,
                    Headline = dto.Headline,
                    Subheading = dto.Subheading,
                    Content = dto.Content,
                    Category = dto.Category,
                    Status = dto.Status,
                    Image = newImageBytes
                };

                var result = repository.UpdateArticleFromEditor(article, dto.RemoveImage);

                string message = result switch
                {
                    1 => "Article updated.",
                    -1 => "Article not found.",
                    -99 => "An error occurred.",
                    _ => "Unexpected result."
                };

                return Ok(new { success = result == 1, message });
            }
            catch (Exception)
            {
                return StatusCode(500, new { success = false, message = "Server error." });
            }
        }

        [HttpGet("approved-articles")]
        public JsonResult GetApprovedArticles()
        {
            try
            {
                var articles = repository.GetArticlesByStatus("Approved");
                return new JsonResult(new { success = true, data = articles });
            }
            catch
            {
                return new JsonResult(new { success = false, message = "Failed to load articles." });
            }
        }

        [HttpGet("full-article/{articleId}")]
        public JsonResult GetFullArticleByArticleId(int articleId)
        {
            try
            {
                var article = repository.GetArticleByArticleId(articleId);
                if (article == null)
                    return new JsonResult(new { success = false, message = "Article not found." });

                var author = repository.GetUserById(article.AuthorId);
                if (author == null)
                    return new JsonResult(new { success = false, message = "Author not found." });


                var dto = new ArticleDisplayDTO
                {
                    ArticleId = article.ArticleId,
                    Headline = article.Headline,
                    Subheading = article.Subheading,
                    Content = article.Content,
                    Category = article.Category,
                    Status = article.Status,
                    ImageBase64 = article.Image != null ? Convert.ToBase64String(article.Image) : null,
                    AuthorUsername = author.Username,
                    AuthorFullName = $"{author.FirstName} {author.LastName}"
                };

                return new JsonResult(new { success = true, data = dto });
            }
            catch
            {
                return new JsonResult(new { success = false, message = "An error occurred while loading the article." });
            }
        }

        [HttpPost("comment")]
        public IActionResult AddComment([FromBody] CommentDTO dto)
        {
            var result = repository.AddComment(dto.ArticleId, dto.UserId, dto.Content);
            return Ok(new { success = result == 1 });
        }

        [HttpGet("comments/{articleId}")]
        public IActionResult GetComments(int articleId)
        {
            var comments = repository.GetCommentsForArticle(articleId);
            return Ok(new { success = true, data = comments });
        }

        [HttpPost("rate")]
        public IActionResult RateArticle([FromBody] RatingDTO dto)
        {
            var result = repository.SetArticleRating(dto.ArticleId, dto.UserId, dto.Stars);
            return Ok(new { success = result == 1 });
        }

        [HttpGet("rating/average/{articleId}")]
        public IActionResult GetAverageRating(int articleId)
        {
            double average = repository.GetAverageRating(articleId);
            return Ok(new { success = true, average });
        }

        [HttpGet("rating/user/{articleId}/{userId}")]
        public IActionResult GetUserRating(int articleId, int userId)
        {
            int? userRating = repository.GetUserRating(articleId, userId);
            return Ok(new { success = true, userRating });
        }

        [HttpPost("report")]
        public IActionResult ReportArticle([FromBody] ReportDTO dto)
        {
            var result = repository.ReportArticle(dto.UserId, dto.ArticleId);
            return Ok(new { success = result == 1 });
        }

        [HttpGet("search")]
        public IActionResult SearchArticles([FromQuery] string? keyword, [FromQuery] string? category)
        {
            try
            {
                var results = repository.SearchArticles(keyword, category);
                return Ok(new { success = true, data = results });
            }
            catch
            {
                return BadRequest(new { success = false, message = "Search failed." });
            }
        }
    }
}
