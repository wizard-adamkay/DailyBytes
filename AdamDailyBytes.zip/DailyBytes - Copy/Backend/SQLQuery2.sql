﻿SELECT * FROM Users

UPDATE Users
SET [Role] = 'Editor'
WHERE UserID = 2;