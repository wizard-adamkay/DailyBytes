import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommentService {
  private baseUrl = 'https://localhost:7255/api/articles';

  constructor(private http: HttpClient) {}

  getComments(articleId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/comments/${articleId}`);
  }

  postComment(articleId: number, userId: number, content: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/comment`, {
      articleId,
      userId,
      content
    });
  }
}
