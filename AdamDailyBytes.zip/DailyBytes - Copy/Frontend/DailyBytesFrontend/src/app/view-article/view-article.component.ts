import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MyArticlesService } from '../my-articles/my-articles.service';
import { BookmarkedArticlesService } from '../bookmarked-articles/bookmarked-articles.service';
import { SessionService } from '../session.service';
import { CommentService } from './comment.service';

@Component({
  selector: 'app-view-article',
  templateUrl: './view-article.component.html',
  styleUrls: ['./view-article.component.css']
})
export class ViewArticleComponent implements OnInit {
  article: any;
  imageSrc: string | null = null;
  comments: any[] = [];
  newComment: string = '';
  userId!: number;
  isBookmarked: boolean = false;
  averageRating: number = 0;
  userRating: number = 0;
  hoverRating: number = 0;

  constructor(
    private route: ActivatedRoute,
    private articleService: MyArticlesService,
    private bookmarkService: BookmarkedArticlesService,
    private sessionService: SessionService,
    private commentService: CommentService,
    private router: Router
    
  ) {}

  

ngOnInit(): void {
  const id = Number(this.route.snapshot.paramMap.get('id'));
  this.userId = Number(this.sessionService.getUserID());

  this.articleService.getArticleById(id).subscribe(res => {
    if (res.success) {
      this.article = res.data;
      if (this.article.image) {
        this.imageSrc = `data:image/png;base64,${this.article.image}`;
      }

      if (this.userId) {
        this.checkIfBookmarked();
      }
      
    }
    this.loadRating();
    this.loadComments();
  });
}

loadRating(): void {
  if (!this.article?.articleId || !this.userId) return;

  this.articleService.getAverageRating(this.article.articleId).subscribe(res => {
    if (res.success) this.averageRating = res.average;
  });

  this.articleService.getUserRating(this.article.articleId, this.userId).subscribe(res => {
    if (res.success) this.userRating = res.userRating ?? 0;
  });
}

setRating(stars: number): void {
  if (!this.userId) return;

  this.articleService.submitRating(this.article.articleId, this.userId, stars).subscribe(res => {
    if (res.success) {
      this.userRating = stars;
      this.loadRating();
    }
  });
}

loadComments(): void {
  const id = Number(this.route.snapshot.paramMap.get('id'));
  this.commentService.getComments(id).subscribe(res => {
    if (res.success) {
      this.comments = res.data;
    }
  });
}

submitComment(): void {
  if (!this.newComment.trim()) return;

  this.commentService
    .postComment(this.article.articleId, this.userId, this.newComment.trim())
    .subscribe(res => {
      if (res.success) {
        this.newComment = '';
        this.loadComments();
      }
    });
}

checkIfBookmarked(): void {
  this.bookmarkService.getBookmarkedArticles(this.userId).subscribe(res => {
    if (res.success) {
      this.isBookmarked = res.data.some((a: any) => a.articleId === this.article.articleId);
    }
  });
}

toggleBookmark(): void {
  if (this.isBookmarked) {
    this.bookmarkService.unbookmarkArticle(this.userId, this.article.articleId).subscribe(() => {
      this.isBookmarked = false;
    });
  } else {
    this.bookmarkService.bookmarkArticle(this.userId, this.article.articleId).subscribe(() => {
      this.isBookmarked = true;
    });
  }
}


reportArticle(): void {
  if (!this.userId) return;

  this.articleService.reportArticle(this.article.articleId, this.userId).subscribe(res => {
    if (res.success) {
      alert("Thanks for reporting this article.");
    }
  });
}
  
  goToAuthor(): void {
    this.router.navigate(['/user', this.article.authorUsername]);
  }
}