import { Component } from '@angular/core';
import { SessionService } from '../session.service';
import { MyArticlesService } from './my-articles.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-my-articles',
  templateUrl: './my-articles.component.html',
  styleUrls: ['./my-articles.component.css']
})
export class MyArticlesComponent {
  articles: any[] = [];
  userId: string | null = null;
  
  constructor(private sessionService: SessionService, private articleService: MyArticlesService, private router: Router) {}
  
  ngOnInit(): void {
    this.userId = this.sessionService.getUserID();
    if (!this.userId) return;
  
    this.articleService.getMyArticles(+this.userId).subscribe(res => {
      if (res.success) {
        this.articles = res.data;
      }
    });
  }
  
  createArticle(): void {
    const idAsString = this.sessionService.getUserID();
    const idAsNum = idAsString ? parseInt(idAsString) : null;
    // need to add this null check otherwise it wont work
    if(idAsNum === null || isNaN(idAsNum)){
      alert("are you logged in?");
      return;
    }
    this.articleService.postNewArticle(idAsNum).subscribe(res => {
      if (res.success) {
        this.router.navigate([`/edit-article/${res.articleId}`]);
      }
      else {
        alert("Failed to create article.");
      }
    });
    
  }
  
  editArticle(articleId: number): void {
    this.router.navigate(['/edit-article', articleId]);
  }
}
