import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MyArticlesService {
  private articleURL = "https://localhost:7255/api/articles";
  constructor(private http: HttpClient) { }

  getMyArticles(userId: number): Observable<any> {
    return this.http.get(`${this.articleURL}/${userId}`);
  }

  postNewArticle(authorId: number): Observable<any> {
    return this.http.post(`${this.articleURL}/create`, { authorId: authorId });
  }

  saveArticle(formData: FormData): Observable<any> {
    return this.http.post(`${this.articleURL}/save`, formData);
  }

  submitArticle(formData: FormData): Observable<any> {
    return this.http.post(`${this.articleURL}/submit`, formData);
  }

  getArticleById(articleId: number): Observable<any> {
    return this.http.get(`${this.articleURL}/article/${articleId}`);
  }

  getFullArticleById(articleId: number): Observable<any> {
    return this.http.get(`${this.articleURL}/full-article/${articleId}`);
  }

  getApprovedArticles(): Observable<any> {
    return this.http.get<any>(`${this.articleURL}/approved-articles`);
  }
  
  submitRating(articleId: number, userId: number, stars: number): Observable<any> {
    return this.http.post(`${this.articleURL}/rate`, { articleId, userId, stars });
  }

  getAverageRating(articleId: number): Observable<any> {
    return this.http.get(`${this.articleURL}/rating/average/${articleId}`);
  }
  
  getUserRating(articleId: number, userId: number): Observable<any> {
    return this.http.get(`${this.articleURL}/rating/user/${articleId}/${userId}`);
  }

  reportArticle(articleId: number, userId: number): Observable<any> {
    return this.http.post(`${this.articleURL}/report`, { articleId, userId });
  }

  searchArticles(keyword?: string, category?: string): Observable<any> {
    let params: any = {};
    if (keyword) params.keyword = keyword;
    if (category) params.category = category;
  
    return this.http.get(`${this.articleURL}/search`, { params });
  }
}
