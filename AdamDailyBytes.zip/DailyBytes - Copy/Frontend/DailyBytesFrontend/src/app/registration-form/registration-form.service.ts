import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class RegistrationFormService {

  private registrationURL = "https://localhost:7255/api/auth/register";
  constructor(private http: HttpClient) { }
  
  register(formDate:FormData) : Observable<any>
  {
    return <Observable<any>> this.http.post(this.registrationURL, formDate);
  }
}