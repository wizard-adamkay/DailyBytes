import { Component, OnInit  } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegistrationFormService } from './registration-form.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration-form',
  templateUrl: './registration-form.component.html',
  styleUrls: ['./registration-form.component.css']
})
export class RegistrationFormComponent implements OnInit {
  registerForm!: FormGroup;
  imageRequiredError = false;
  selectedFile: File | null = null;
  genderOptions = ['Male', 'Female', 'Other'];
  
  constructor(private formBuilder: FormBuilder, private registrationFormService: RegistrationFormService, private router: Router) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.pattern(/^[A-Za-z]+$/)]],
      lastName: ['', [Validators.required, Validators.pattern(/^[A-Za-z]+$/)]],
      email: ['', [Validators.required, Validators.email]],
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,}$/)]],
      gender: ['', Validators.required],
      contactNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      dateOfBirth: ['', [Validators.required, this.dateBeforeTodayValidator]],
      address: ['', Validators.required]
    });
  }

  dateBeforeTodayValidator(control: AbstractControl) {
    const inputDate = new Date(control.value);
    const today = new Date();
    if (inputDate >= today) {
      return { invalidDate: true };
    }
    return null;
  }
  
  onSubmit(){
    if (!this.registerForm.valid) {
      console.log("AHHHHH");
      return;
    }
    if (!this.selectedFile) {
      this.imageRequiredError = true;
      return;
    }
  const formData = new FormData();
  formData.append('FirstName', this.registerForm.value.firstName);
  formData.append('LastName', this.registerForm.value.lastName);
  formData.append('Email', this.registerForm.value.email);
  formData.append('Username', this.registerForm.value.username);
  formData.append('Password', this.registerForm.value.password);
  formData.append('Gender', this.registerForm.value.gender);
  formData.append('ContactNumber', this.registerForm.value.contactNumber);
  formData.append('DateOfBirth', this.registerForm.value.dateOfBirth);
  formData.append('Address', this.registerForm.value.address);
  formData.append('ProfilePicture', this.selectedFile);

  this.registrationFormService.register(formData).subscribe({
    next: (res) => {
      alert(res.message);
      if (res.success) {
        this.router.navigate(['/home']);
      }
    },
    error: (err) => {
      alert("Something went wrong during registration.");
      console.error(err);
    }
  });
  }


  onFileSelected(event: any): void {
    const file: File = event.target.files[0];
  
    if (file && file.type === 'image/png') {
      this.selectedFile = file;
      this.imageRequiredError = false;
    } else {
      this.selectedFile = null;
      this.imageRequiredError = true;
      alert("Please select a PNG image.");
    }
  }
}
