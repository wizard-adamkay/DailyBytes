import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { LoginService } from './login.service';
import { SessionService } from '../session.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;

  constructor(private fb: FormBuilder, private loginService: LoginService, private router: Router, private sessionService: SessionService) {}

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.loginForm.invalid) return;
    this.loginService.login(this.loginForm.value)
      .subscribe({
        next: res => {
          alert(res.message);
          if (res.success) {
            this.sessionService.setUserSession(res.userID, res.username, res.role);
            this.router.navigate(['/home']).then(() => location.reload());
          }
        },
        error: err => {
          alert("Login failed.");
          console.error(err);
        }
      });
  }
}