import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyArticlesService } from '../my-articles/my-articles.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  approvedArticles: any[] = [];

  constructor(private articleService: MyArticlesService, private router: Router) {}

  ngOnInit(): void {
    this.articleService.getApprovedArticles().subscribe(res => {
      if (res.success) {
        this.approvedArticles = res.data;
      }
    });
  }

  openArticle(id: number): void {
    this.router.navigate(['/article', id]);
  }

  goToSearch(): void {
    this.router.navigate(['/search']);
  }
}