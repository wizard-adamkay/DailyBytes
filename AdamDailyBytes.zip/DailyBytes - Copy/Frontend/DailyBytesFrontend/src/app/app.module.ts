import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import { RegistrationFormService } from './registration-form/registration-form.service';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { MyArticlesComponent } from './my-articles/my-articles.component';
import { EditArticleComponent } from './edit-article/edit-article.component';
import { ReviewArticlesComponent } from './review-articles/review-articles.component';
import { EditorArticleReviewComponent } from './editor-article-review/editor-article-review.component';
import { ViewArticleComponent } from './view-article/view-article.component';
import { BookmarkedArticlesComponent } from './bookmarked-articles/bookmarked-articles.component';
import { SearchArticlesComponent } from './search-articles/search-articles.component';
import { NotificationsComponent } from './notifications/notifications.component';

@NgModule({
  declarations: [
    AppComponent,
    RegistrationFormComponent,
    LoginComponent,
    HomeComponent,
    UserProfileComponent,
    EditProfileComponent,
    MyArticlesComponent,
    EditArticleComponent,
    ReviewArticlesComponent,
    EditorArticleReviewComponent,
    ViewArticleComponent,
    BookmarkedArticlesComponent,
    SearchArticlesComponent,
    NotificationsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [ RegistrationFormService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
