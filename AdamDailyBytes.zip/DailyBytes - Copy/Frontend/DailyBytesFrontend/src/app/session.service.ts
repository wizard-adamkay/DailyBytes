import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SessionService {

  setUserSession(userID: string, username: string, role: string): void {
    sessionStorage.setItem('userID', userID);
    sessionStorage.setItem('username', username);
    sessionStorage.setItem('role', role);
  }

  clearSession(): void {
    sessionStorage.clear();
  }

  getUsername(): string | null {
    return sessionStorage.getItem('username');
  }

  setUsername(username: string): void {
    sessionStorage.setItem('username', username);
  }

  getUserID(): string | null {
    return sessionStorage.getItem('userID');
  }

  getRole(): string | null {
    return sessionStorage.getItem('role');
  }

  isLoggedIn(): boolean {
    return !!this.getUsername();
  }

  // Optional: Check role
  isEditor(): boolean {
    return this.getRole() === 'Editor';
  }

  isJournalist(): boolean {
    return this.getRole() === 'Journalist';
  }

  isChiefEditor(): boolean {
    return this.getRole() === 'Chief Editor';
  }
}
