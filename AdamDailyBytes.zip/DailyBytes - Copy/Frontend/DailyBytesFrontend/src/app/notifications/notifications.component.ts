import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SessionService } from '../session.service';
import { NotificationService } from '../notification.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {
  notifications: any[] = [];
  userId: number = 0;

  constructor(
    private notificationService: NotificationService,
    private router: Router,
    private sessionService: SessionService
  ) {}

  ngOnInit(): void {
    const id = this.sessionService.getUserID();
    this.userId = id ? +id : 0;
    this.notificationService.getNotifications(this.userId).subscribe(res => {
      if (res.success) this.notifications = res.data;
    });
  }

  openNotification(notificationId: number, articleId: number): void {
    this.notificationService.markAsRead(notificationId).subscribe(() => {
      this.notifications = this.notifications.filter(n => n.notificationId !== notificationId);
      this.router.navigate(['/article', articleId]);
    });
  }
}