import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SessionService } from '../session.service';
import { UserProfileService } from '../user-profile/user-profile.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html'
})
export class EditProfileComponent implements OnInit {
  profileForm!: FormGroup;
  selectedFile: File | null = null;
  role: string | null = null;
  userId: string | null = null;
  showExtendedFields = false;
  genderOptions = ['Male', 'Female', 'Other'];
  availableCategories: string[] = [
    'Entertainment', 'Sports', 'Politics',
    'Current Affairs', 'Editorial', 'Business', 'Education'
  ];
  selectedCategories: string[] = [];

  constructor(
    private fb: FormBuilder,
    private sessionService: SessionService,
    private userProfileService: UserProfileService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    const loggedInUsername = this.sessionService.getUsername();
    const routeUsername = this.route.snapshot.paramMap.get('username');

    if (routeUsername && loggedInUsername !== routeUsername) {
      alert("You can't edit another user's profile.");
      this.router.navigate(['/home']);
      return;
    }


    this.role = this.sessionService.getRole();
    this.userId = this.sessionService.getUserID();

    this.showExtendedFields = ['Journalist', 'Editor', 'Chief Editor'].includes(this.role ?? '');

    this.profileForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.pattern(/^[A-Za-z]+$/)]],
      lastName: ['', [Validators.required, Validators.pattern(/^[A-Za-z]+$/)]],
      email: ['', [Validators.required, Validators.email]],
      username: ['', Validators.required],
      password: ['', [Validators.pattern(/^$|^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,}$/)]],
      gender: ['', Validators.required],
      contactNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      dateOfBirth: ['', [Validators.required, this.dateBeforeTodayValidator]],
      address: ['', Validators.required],
      bio: [''],
      interests: [''],
      experience: [''],
      views: [''],
      twitter: [''],
      facebook: [''],
      instagram: [''],
      linkedIn: ['']
    });

    this.loadUserProfile();
  }

  onCategoryChange(event: any): void {
    const value = event.target.value;
    if (event.target.checked) {
      this.selectedCategories.push(value);
    } else {
      this.selectedCategories = this.selectedCategories.filter(c => c !== value);
    }
  }
  dateBeforeTodayValidator(control: AbstractControl) {
    const inputDate = new Date(control.value);
    const today = new Date();
    if (inputDate >= today) {
      return { invalidDate: true };
    }
    return null;
  }

  loadUserProfile(): void {
    const username = this.sessionService.getUsername();
    if (!username) return;

    this.userProfileService.getUserEditProfile(username).subscribe(res => {
      if (res.success) {
        const user = res.data;
        this.profileForm.patchValue({
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          username: user.username,
          password: user.password,
          gender: user.gender,
          contactNumber: user.contactNumber,
          dateOfBirth: user.dateOfBirth,
          address: user.address,
          bio: user.bio,
          interests: user.interests,
          experience: user.experience,
          views: user.views,
          twitter: user.twitter,
          facebook: user.facebook,
          instagram: user.instagram,
          linkedIn: user.linkedIn
        });
        this.selectedCategories = user.categories || [];
      }
    });
  }

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file && file.type === 'image/png') {
      this.selectedFile = file;
    } else {
      this.selectedFile = null;
      alert("Only PNG images are allowed.");
    }
  }

  onSubmit(): void {
    const formData = new FormData();
    formData.append('UserId', this.userId!);
    formData.append('FirstName', this.profileForm.value.firstName);
    formData.append('LastName', this.profileForm.value.lastName);
    formData.append('Email', this.profileForm.value.email);
    formData.append('Username', this.profileForm.value.username);
    //only append if theres a password
    const password = this.profileForm.value.password;
    if (password && password.trim() !== '') {
      formData.append('Password', password);
    }
    formData.append('Gender', this.profileForm.value.gender);
    formData.append('ContactNumber', this.profileForm.value.contactNumber);
    formData.append('DateOfBirth', this.profileForm.value.dateOfBirth);
    formData.append('Address', this.profileForm.value.address);
    this.selectedCategories.forEach(category => {
      formData.append('Categories', category);
    });

    if (this.selectedFile) {
      formData.append('ProfilePicture', this.selectedFile);
    }

    if (this.showExtendedFields) {
      formData.append('Bio', this.profileForm.value.bio);
      formData.append('Interests', this.profileForm.value.interests);
      formData.append('Experience', this.profileForm.value.experience);
      formData.append('Views', this.profileForm.value.views);
      formData.append('Twitter', this.profileForm.value.twitter);
      formData.append('Facebook', this.profileForm.value.facebook);
      formData.append('Instagram', this.profileForm.value.instagram);
      formData.append('LinkedIn', this.profileForm.value.linkedIn);

      this.userProfileService.updateExtended(formData).subscribe(res => {
        alert(res.message);
        if (res.success) {
          this.sessionService.setUsername(this.profileForm.value.username);
          this.router.navigate(['/user', this.sessionService.getUsername()]);
          
        }
      });
    } else {
      this.userProfileService.updateBasic(formData).subscribe(res => {
        alert(res.message);
        this.sessionService.setUsername(this.profileForm.value.username);
        if (res.success) this.router.navigate(['/user', this.sessionService.getUsername()]);
      });
    }
  }
}