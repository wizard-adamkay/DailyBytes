import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EditorArticleReviewService {
  private articleURL = "https://localhost:7255/api/articles/editor-update";
  constructor(private http: HttpClient) { }

  updateArticleFromEditor(formData: FormData) {
    return this.http.put<any>(this.articleURL, formData);
  }
}
