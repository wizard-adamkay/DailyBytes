
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MyArticlesService } from '../my-articles/my-articles.service';
import { EditorArticleReviewService } from './editor-article-review.service';

@Component({
  selector: 'app-editor-article-review',
  templateUrl: './editor-article-review.component.html',
  styleUrls: ['./editor-article-review.component.css']
})
export class EditorArticleReviewComponent implements OnInit{
  articleForm!: FormGroup;
  articleId!: number;
  selectedFile: File | null = null;
  existingImage: string | null = null;
  removeImage: boolean = false;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private myArticleService: MyArticlesService,
    private editorArticleService: EditorArticleReviewService
  ) {}

  ngOnInit(): void {
    this.articleId = Number(this.route.snapshot.paramMap.get('id'));

    this.articleForm = this.fb.group({
      headline: ['', Validators.required],
      subheading: ['', Validators.required],
      content: ['', Validators.required],
      category: [''],
      status: ['']
    });

    this.loadArticle();
  }

  loadArticle(): void {
    this.myArticleService.getArticleById(this.articleId).subscribe(res => {
      if (res.success) {
        const article = res.data;
        this.articleForm.patchValue({
          headline: article.headline,
          subheading: article.subheading,
          content: article.content,
          category: article.category,
          status: article.status
        });

        if (article.image) {
          this.existingImage = `data:image/png;base64,${article.image}`;
        }
      }
    });
  }

  onFileSelected(event: any): void {
    const file = event.target.files[0];
  
    if (file && file.type === 'image/png') {
      this.selectedFile = file;
      this.removeImage = false;
  
      const reader = new FileReader();
      reader.onload = () => {
        this.existingImage = reader.result as string;
      };
      reader.readAsDataURL(file);
    } else {
      alert('Only PNG images are allowed.');
    }
  }

  removeCurrentImage(): void {
    this.removeImage = true;
    this.selectedFile = null;
    this.existingImage = null;
  }

  onSubmit(): void {
    if (this.articleForm.invalid) {
      this.articleForm.markAllAsTouched();
      return;
    }

    const formData = new FormData();
    formData.append('ArticleId', this.articleId.toString());
    formData.append('Headline', this.articleForm.value.headline);
    formData.append('Subheading', this.articleForm.value.subheading);
    formData.append('Content', this.articleForm.value.content);
    formData.append('Category', this.articleForm.value.category);
    formData.append('Status', this.articleForm.value.status);
    formData.append('RemoveImage', this.removeImage.toString());

    if (this.selectedFile) {
      formData.append('Image', this.selectedFile);
    }

    this.editorArticleService.updateArticleFromEditor(formData).subscribe(res => {
      alert(res.message);
      if (res.success) {
        this.router.navigate(['/review-articles']);
      }
    });
  }
}
