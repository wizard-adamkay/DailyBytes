import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditorArticleReviewComponent } from './editor-article-review.component';

describe('EditorArticleReviewComponent', () => {
  let component: EditorArticleReviewComponent;
  let fixture: ComponentFixture<EditorArticleReviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditorArticleReviewComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditorArticleReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
