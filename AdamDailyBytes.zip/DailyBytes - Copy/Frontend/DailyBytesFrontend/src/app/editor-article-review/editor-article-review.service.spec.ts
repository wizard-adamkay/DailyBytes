import { TestBed } from '@angular/core/testing';

import { EditorArticleReviewService } from './editor-article-review.service';

describe('EditorArticleReviewService', () => {
  let service: EditorArticleReviewService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EditorArticleReviewService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
