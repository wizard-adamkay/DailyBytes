import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MyArticlesService } from '../my-articles/my-articles.service';
import { SessionService } from '../session.service';
import { EditArticleService } from './edit-article.service';

@Component({
  selector: 'app-edit-article',
  templateUrl: './edit-article.component.html',
  styleUrls: ['./edit-article.component.css']
})
export class EditArticleComponent implements OnInit{
  articleForm!: FormGroup;
  articleId!: number;
  selectedFile: File | null = null;
  editors: any[] = [];

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private articleService: MyArticlesService,
    private sessionService: SessionService,
    private editArticleService: EditArticleService
  ) {}

  ngOnInit(): void {
    this.articleId = Number(this.route.snapshot.paramMap.get('articleId'));

    this.articleForm = this.fb.group({
      headline: ['', Validators.required],
      subheading: ['', Validators.required],
      content: ['', Validators.required],
      category: ['', Validators.required],
      editorId: ['', Validators.required]
    });

    this.loadArticle();
    this.loadEditors();
  }
  loadEditors() {
    this.editArticleService.getEditors().subscribe(res =>
    {
      if (res.success) {
        this.editors = res.data;
      }
    });
  }

  loadArticle(): void {
    this.articleService.getArticleById(this.articleId).subscribe(res => {
      if (res.success) {
        const article = res.data;
        this.articleForm.patchValue({
          headline: article.headline,
          subheading: article.subheading,
          content: article.content,
          category: article.category,
          editorId: article.editorId
        });
      }
    });
  }

  

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file && file.type === 'image/png') {
      this.selectedFile = file;
    } else {
      this.selectedFile = null;
      alert('Only PNG images are allowed.');
    }
  }

  private buildFormData(forSubmit: boolean): FormData {
    const formData = new FormData();
    formData.append('ArticleId', this.articleId.toString());
    formData.append('Headline', this.articleForm.value.headline || '');
    formData.append('Subheading', this.articleForm.value.subheading || '');
    formData.append('Content', this.articleForm.value.content || '');
    formData.append('Category', this.articleForm.value.category || '');
    formData.append('EditorId', this.articleForm.value.editorId || '');

    if (this.selectedFile) {
      formData.append('Image', this.selectedFile);
    }

    if (forSubmit) {
      const authorId = this.sessionService.getUserID();
      if (authorId) {
        formData.append('AuthorId', authorId);
      }
    }

    return formData;
  }

  onSave(): void {
    const formData = this.buildFormData(false);
    this.articleService.saveArticle(formData).subscribe(res => {
      alert(res.message);
    });
  }

  onSubmit(): void {
    if (this.articleForm.invalid) {
      this.articleForm.markAllAsTouched();
      return;
    }

    const formData = this.buildFormData(true);
    this.articleService.submitArticle(formData).subscribe(res => {
      alert(res.message);
      if (res.success) {
        this.router.navigate(['/my-articles']);
      }
    });
  }
}
