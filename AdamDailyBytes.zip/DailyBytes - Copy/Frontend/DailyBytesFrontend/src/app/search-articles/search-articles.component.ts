import { Component } from '@angular/core';
import { MyArticlesService } from '../my-articles/my-articles.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search-articles',
  templateUrl: './search-articles.component.html',
  styleUrls: ['./search-articles.component.css']
})
export class SearchArticlesComponent {
  keyword: string = '';
  selectedCategory: string = '';
  results: any[] = [];
  categories: string[] = [
    'Entertainment', 'Sports', 'Politics', 'Current Affairs',
    'Editorial', 'Business', 'Education'
  ];

  constructor(private articleService: MyArticlesService, private router: Router) {}

  search(): void {
    this.articleService
      .searchArticles(this.keyword.trim(), this.selectedCategory)
      .subscribe(res => {
        if (res.success) {
          this.results = res.data;
        }
      });
  }

  viewArticle(articleId: number): void {
    this.router.navigate(['/view-article', articleId]);
  }
}