import { TestBed } from '@angular/core/testing';

import { BookmarkedArticlesService } from './bookmarked-articles.service';

describe('BookmarkedArticlesService', () => {
  let service: BookmarkedArticlesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BookmarkedArticlesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
