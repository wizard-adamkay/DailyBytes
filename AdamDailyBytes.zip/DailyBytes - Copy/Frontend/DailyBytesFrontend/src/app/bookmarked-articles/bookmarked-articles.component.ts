import { Component, OnInit } from '@angular/core';
import { SessionService } from '../session.service';
import { BookmarkedArticlesService } from './bookmarked-articles.service';

@Component({
  selector: 'app-bookmarked-articles',
  templateUrl: './bookmarked-articles.component.html',
  styleUrls: ['./bookmarked-articles.component.css']
})
export class BookmarkedArticlesComponent implements OnInit {
  articles: any[] = [];
  userId!: number;

  constructor(private bookmarkService: BookmarkedArticlesService, private sessionService: SessionService) {}

  ngOnInit(): void {
    this.userId = Number(this.sessionService.getUserID());
    this.bookmarkService.getBookmarkedArticles(this.userId).subscribe(res => {
      if (res.success) {
        this.articles = res.data;
      }
    });
  }
}
