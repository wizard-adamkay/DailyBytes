import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookmarkedArticlesService {
  private articleURL = "https://localhost:7255/api/bookmark";
  constructor(private http: HttpClient) { }

  bookmarkArticle(userId: number, articleId: number): Observable<any> {
    return this.http.post<any>(`${this.articleURL}/bookmark`, { userId, articleId });
  }
  
  unbookmarkArticle(userId: number, articleId: number): Observable<any> {
    //Janky work around because delete wont let me send a request body
    return this.http.request<any>('DELETE', `${this.articleURL}/bookmark`, {
      body: { userId, articleId }
    });
  }
  
  getBookmarkedArticles(userId: number): Observable<any> {
    return this.http.get<any>(`${this.articleURL}/bookmarks/${userId}`);
  }

}
