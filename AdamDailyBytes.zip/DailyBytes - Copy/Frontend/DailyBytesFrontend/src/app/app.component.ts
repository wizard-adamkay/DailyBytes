import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SessionService } from './session.service';
import { NotificationService } from './notification.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  userName: string | null = null;
  notifications: any[] = [];
  constructor(
    public sessionService: SessionService,
    private notificationService: NotificationService,
    private router: Router
  ) {}

  isJournalistOrAbove(): boolean {
    const role = this.sessionService.getRole();
    return ['Journalist', 'Editor', 'Chief Editor'].includes(role ?? '');
  }

  isEditorOrAbove(): boolean {
    const role = this.sessionService.getRole();
    return ['Editor', 'Chief Editor'].includes(role ?? '');
  }
  
  ngOnInit(): void {
    this.userName = this.sessionService.getUsername();
    const userId = this.sessionService.getUserID();
    if (userId) {
      this.notificationService.getNotifications(+userId).subscribe(res => {
        if (res.success) this.notifications = res.data;
      });
    }
  }
  goToNotifications(): void {
    this.router.navigate(['/notifications']);
  }
  
  login(): void {
    this.router.navigate(['/login']);
  }

  register(): void {
    this.router.navigate(['/register']);
  }

  logout(): void {
    this.sessionService.clearSession();
    this.userName = null;
    this.router.navigate(['/home']);
  }

  isLoggedIn(): boolean {
    return this.sessionService.isLoggedIn();
  }

  goToProfile(): void {
    if (this.userName) {
      this.router.navigate([`/user/${this.userName}`]);
    }
  }

  goToHome(): void {
    this.router.navigate(["/home"]);
  }
}
