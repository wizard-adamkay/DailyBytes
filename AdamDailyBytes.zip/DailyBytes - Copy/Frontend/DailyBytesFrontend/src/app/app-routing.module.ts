import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import { HomeComponent } from './home/home.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { MyArticlesComponent } from './my-articles/my-articles.component';
import { EditArticleComponent } from './edit-article/edit-article.component';
import { ReviewArticlesComponent } from './review-articles/review-articles.component';
import { EditorArticleReviewComponent } from './editor-article-review/editor-article-review.component';
import { ViewArticleComponent } from './view-article/view-article.component';
import { BookmarkedArticlesComponent } from './bookmarked-articles/bookmarked-articles.component';
import { SearchArticlesComponent } from './search-articles/search-articles.component';
import { NotificationsComponent } from './notifications/notifications.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegistrationFormComponent },
  { path: 'home', component: HomeComponent },
  { path: 'user/:username', component: UserProfileComponent },
  { path: 'edit-profile', component: EditProfileComponent },
  { path: 'my-articles', component: MyArticlesComponent },
  { path: 'edit-article/:articleId', component: EditArticleComponent },
  { path: 'review-articles', component: ReviewArticlesComponent },
  { path: 'editor-review/:id', component: EditorArticleReviewComponent },
  { path: 'article/:id', component: ViewArticleComponent },
  { path: 'bookmarked', component: BookmarkedArticlesComponent },
  { path: 'search', component: SearchArticlesComponent },
  { path: 'notifications', component: NotificationsComponent }
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
