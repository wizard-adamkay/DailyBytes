import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  private notificationUrl = "https://localhost:7255/api/auth";

  constructor(private http: HttpClient) { }

  getNotifications(userId: number): Observable<any> {
    return this.http.get(`${this.notificationUrl}/notifications/${userId}`);
  }
  
  markAsRead(notificationId: number): Observable<any> {
    return this.http.post(`${this.notificationUrl}/notifications/read/${notificationId}`, {});
  }
}
