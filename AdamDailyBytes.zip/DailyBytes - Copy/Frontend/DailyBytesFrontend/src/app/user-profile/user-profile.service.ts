import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserProfileService {
  private apiUrl = 'https://localhost:7255/api/auth/update/';
  private profileApiUrl = 'https://localhost:7255/api/auth/user/';
  private authControllerUrl = 'https://localhost:7255/api/auth';
  constructor(private http: HttpClient) {}

  getUserProfile(username: string): Observable<any> {
    return this.http.get(`${this.profileApiUrl}${username}`);
  }

  getUserEditProfile(username: string): Observable<any> {
    return this.http.get(`${this.profileApiUrl}edit/${username}`);
  }

  updateBasic(formData: FormData): Observable<any> {
    return this.http.put(`${this.apiUrl}basic`, formData);
  }
  
  updateExtended(formData: FormData): Observable<any> {
    return this.http.put(`${this.apiUrl}extended`, formData);
  }

  followUser(followerId: number, followeeId: number): Observable<any> {
    return this.http.post(`${this.authControllerUrl}/follow`, { followerId, followeeId });
  }
  
  unfollowUser(followerId: number, followeeId: number): Observable<any> {
    return this.http.request('DELETE', `${this.authControllerUrl}/unfollow`, {
      body: { followerId, followeeId }
    });
  }
  
  isFollowing(followerId: number, followeeId: number): Observable<any> {
    return this.http.get<any>(`${this.authControllerUrl}/is-following/${followerId}/${followeeId}`);
  }
}
