import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserProfileService } from './user-profile.service';
import { SessionService } from '../session.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  username: string | null = null;
  currentUser: string | null = null;
  role: string | null = null;
  profilePictureUrl: string | null = null;
  bio: string | null = null;
  interests: string | null = null;
  experience: string | null = null;
  views: string | null = null;
  socialLinks: any = {};
  isJournalistOrAbove = false;
  followeeId: number | null = null;
  followerId: number | null = null;
  isFollowing: boolean = false;
  canFollow: boolean = false;

  constructor(private router: Router, private route: ActivatedRoute, private userService: UserProfileService, private sessionService : SessionService) {}

  ngOnInit(): void {
    this.currentUser = this.sessionService.getUsername();
    this.username = this.route.snapshot.paramMap.get('username');
    if (this.username) {
      this.userService.getUserProfile(this.username).subscribe(res => {
        if (res.success) {
          this.role = res.data.role;
          this.profilePictureUrl = res.data.profilePicture
            ? `data:image/png;base64,${res.data.profilePicture}`: null;
          this.interests = res.data.interests;
          this.experience = res.data.experience;
          this.views = res.data.views;
          this.bio = res.data.bio;
          this.socialLinks = {
            twitter: res.data.twitter,
            facebook: res.data.facebook,
            instagram: res.data.instagram,
            linkedIn: res.data.linkedIn
          };
          this.isJournalistOrAbove = ['Journalist', 'Editor', 'Chief Editor'].includes(this.role ?? '');
          this.followeeId = res.data.userId;
          this.followerId = this.sessionService.getUserID() ? Number(this.sessionService.getUserID()) : null;
          
          this.canFollow = !!this.followerId &&
                           this.followerId !== this.followeeId &&
                           ['Journalist', 'Editor', 'Chief Editor'].includes(this.role ?? '');
          
          if (this.canFollow) {
            this.userService.isFollowing(this.followerId!, this.followeeId!).subscribe(res => {
              if (res.success) this.isFollowing = res.isFollowing;
            });
          }
        }
      });
    }
    
  }

  toggleFollow(): void {
    if (!this.followerId || !this.followeeId) return;
  
    if (this.isFollowing) {
      this.userService.unfollowUser(this.followerId, this.followeeId).subscribe(res => {
        if (res.success) this.isFollowing = false;
      });
    } else {
      this.userService.followUser(this.followerId, this.followeeId).subscribe(res => {
        if (res.success) this.isFollowing = true;
      });
    }
  }
  
  goToEdit(): void {
    this.router.navigate(['/edit-profile']);
  }
}