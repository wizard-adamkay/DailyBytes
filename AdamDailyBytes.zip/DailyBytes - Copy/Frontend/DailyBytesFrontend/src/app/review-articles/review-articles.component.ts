import { Component, OnInit } from '@angular/core';
import { SessionService } from '../session.service';
import { Router } from '@angular/router';
import { ReviewArticlesService } from './review-articles.service';
@Component({
  selector: 'app-review-articles',
  templateUrl: './review-articles.component.html',
  styleUrls: ['./review-articles.component.css']
})
export class ReviewArticlesComponent {
  submittedArticles: any[] = [];

  constructor(
    private articleService: ReviewArticlesService,
    private sessionService: SessionService,
    private router: Router
  ) {}
  
  ngOnInit(): void {
    const editorId = this.sessionService.getUserID();
    if (editorId) {
      this.articleService.getSubmittedArticles(+editorId).subscribe(res => {
        if (res.success) {
          this.submittedArticles = res.data;
        }
      });
    }
  }

  reviewArticle(articleId: number): void {
    this.router.navigate([`/editor-review/${articleId}`]);
  }
}