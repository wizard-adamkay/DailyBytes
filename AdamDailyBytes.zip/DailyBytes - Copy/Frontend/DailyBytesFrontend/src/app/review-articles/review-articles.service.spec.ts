import { TestBed } from '@angular/core/testing';

import { ReviewArticlesService } from './review-articles.service';

describe('ReviewArticlesService', () => {
  let service: ReviewArticlesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReviewArticlesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
